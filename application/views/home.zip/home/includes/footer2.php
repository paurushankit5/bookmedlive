        <!--<section class="skincolored_section">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
			  
               <div class="newsletter_form svg_newsletter">
					
                  <div class="row">
                    <div class="col-md-6 right_area">
                    <table width="205" height="90" border="1">
  <tr>
    <td height="69"><img src="<?=base_url('assets/');?>assets/images/button_diagnosis.png"></td>
  </tr>
  <tr>
    <td><img src="<?=base_url('assets/');?>assets/images/button_diagnosis.png"></td>
  </tr>
</table>

                    </div>
                    <div class="col-md-6 right_area">
                   <table width="496" height="130" border="1">
  <tr> 
    <td width="230" height="97"><img src="<?=base_url('assets/');?>assets/images/button_diagnosis.png"></td>
    <td width="230"><img src="<?=base_url('assets/');?>assets/images/button_clinic.png"></td>
    <td width="230"><img src="<?=base_url('assets/');?>assets/images/button_doctor.png"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td></td>
  </tr>
</table>
				  
				    </div>
                  </div>
                </div>
               
              </div>
            </div>
          </div>
        </section>-->